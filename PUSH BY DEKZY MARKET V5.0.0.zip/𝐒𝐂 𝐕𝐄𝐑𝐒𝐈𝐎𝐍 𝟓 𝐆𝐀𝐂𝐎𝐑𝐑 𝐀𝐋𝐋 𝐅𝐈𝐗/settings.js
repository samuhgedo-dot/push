/* 
 NO UBAH CREDIT HARGAI PEMBUATAN SCRIPT INI!!
 No Enc ? Buy Ke Tele >https://t.me/Welperoffcialdev

*/

const chalk = require("chalk");
const fs = require("fs");

global.owner = "6285838486090"
global.namaOwner = "dekzymarket"
global.mode_public = true

global.linkChannel = "https://whatsapp.com/channel/0029Vb669U89xVJnlXO44c3m"
global.idChannel = "120363420703176804@newsletter"
global.linkGrup = ""
global.thumbnail = "https://files.catbox.moe/kgwaxf.jpg"

global.dana = "087883313554"
global.ovo = "Tidak tersedia"
global.gopay = "Tidak tersedia"
global.qris = "https://files.catbox.moe/q506c9.jpg"

global.JedaPushkontak = 5000
global.JedaJpm = 5000

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://server.ricotasya.my.id"
global.apikey = "ptla_xZZxSITraBdGqPT0Ge4nRb3HxLOZW9yX0oDM82J3" // Isi api ptla
global.capikey = "ptlc_TroIQEI72IEJRtMD2ZomZ1CV7Oeoi0ufEyWSWedle" // Isi api ptlc


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${__filename}`))
delete require.cache[file]
require(file)
})