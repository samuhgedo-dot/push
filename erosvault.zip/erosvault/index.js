// index.js
require("./setting/config");
const {
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  jidDecode,
  makeWASocket,
} = require("@adiwajshing/baileys");
const pino = require("pino");
const { Boom } = require("@hapi/boom");
const fs = require("fs");
const chalk = require("chalk");
const figlet = require("figlet");

// === In-memory store ===
const store = makeInMemoryStore({ logger: pino().child({ level: "silent" }) });

// Helper delay
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

// Coloring helper
const color = (t, c) => (!c ? chalk.green(t) : chalk.keyword(c)(t));

async function startEza(reconnectCount = 0) {
  try {
    const { state, saveCreds } = await useMultiFileAuthState("./session");
    const { version } = await fetchLatestBaileysVersion();

    console.log(color(figlet.textSync("push-kontak", { font: "Standard" }), "cyan"));
    console.log(color(`🚀 Engine v6 | WhatsApp v${version.join(".")}`, "green"));

    const client = makeWASocket({
      logger: pino({ level: "silent" }),
      printQRInTerminal: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      auth: state,
    });

    store.bind(client.ev);

    client.decodeJid = (jid) => {
      if (!jid) return jid;
      if (/:\d+@/gi.test(jid)) {
        let d = jidDecode(jid) || {};
        return (d.user && d.server && d.user + "@" + d.server) || jid;
      }
      return jid;
    };

    // === Pasang machine.js ===
    const machine = require("./setting/machine.js");

    client.ev.on("messages.upsert", async ({ messages }) => {
      try {
        const m = messages[0];
        if (!m.message || m.key.remoteJid === "status@broadcast") return;
        machine(client, m); // kirim semua pesan masuk ke machine.js
      } catch (e) {
        console.error("Message error:", e);
      }
    });

    // === Connection update handling ===
    client.ev.on("connection.update", async (u) => {
      const { connection, lastDisconnect } = u;
      if (connection === "close") {
        const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
        const wait = Math.min(60000, 5000 * (reconnectCount + 1));
        console.log(chalk.red(`Koneksi putus (${reason}), reconnect ${wait / 1000}s`));
        setTimeout(() => startEza(reconnectCount + 1), wait);
      } else if (connection === "open") {
        console.log(chalk.greenBright("✅ Terhubung ke WhatsApp!"));
      }
    });

    client.ev.on("creds.update", saveCreds);

    console.log(chalk.greenBright("✅ Bot siap dan worker machine.js berjalan"));

    return client;
  } catch (err) {
    console.error("Fatal error:", err);
    setTimeout(() => startEza(), 10000);
  }
}

startEza();

// === Hot reload otomatis ===
fs.watchFile(require.resolve(__filename), () => {
  delete require.cache[require.resolve(__filename)];
  console.log(chalk.redBright(`\nFile updated: ${__filename}`));
  require(__filename);
});
