// machine.js
const fs = require('fs');
const util = require('util');
const chalk = require('chalk');
const moment = require('moment-timezone');
moment.tz.setDefault('Asia/Jakarta');

const CONFIG = global.machineConfig;

// === Path setup ===
const DATA_DIR = './data';
const PATHS = {
  queue: `${DATA_DIR}/queue.json`,
  state: `${DATA_DIR}/push_state_v6.json`,
  usage: `${DATA_DIR}/usage_day.json`,
  sent: `${DATA_DIR}/sent_today.json`,
  logs: `${DATA_DIR}/logs`
};
for (const p of [DATA_DIR, PATHS.logs]) if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });

// === JSON helpers ===
const readJSON = (p, fb) => { try { return fs.existsSync(p) ? JSON.parse(fs.readFileSync(p)) : fb; } catch { return fb; } };
const writeJSON = (p, d) => { try { fs.writeFileSync(p, JSON.stringify(d, null, 2)) } catch {} };

// === Queue & state ===
let QUEUE = readJSON(PATHS.queue, []);
let STATE = readJSON(PATHS.state, null);
let USAGE = readJSON(PATHS.usage, { date: moment().format('YYYY-MM-DD'), sentToday: 0, dailyLimit: CONFIG.INITIAL_DAILY_LIMIT });
let SENT = readJSON(PATHS.sent, {});
const today = moment().format('YYYY-MM-DD');
if (USAGE.date !== today) USAGE = { date: today, sentToday: 0, dailyLimit: CONFIG.INITIAL_DAILY_LIMIT };
if (!SENT[today]) SENT[today] = {}; writeJSON(PATHS.sent, SENT);

// === Logger ===
function rotateLogs() {
  try {
    const f = `${PATHS.logs}/${moment().format('YYYY-MM-DD')}.log`;
    if (fs.existsSync(f) && fs.statSync(f).size > CONFIG.LOG_MAX_BYTES) {
      fs.renameSync(f, f.replace('.log', `.${Date.now()}.log`));
      const cutoff = Date.now() - CONFIG.LOG_RETENTION_DAYS * 86400000;
      for (const x of fs.readdirSync(PATHS.logs)) {
        const p = `${PATHS.logs}/${x}`;
        if (fs.statSync(p).mtimeMs < cutoff) fs.unlinkSync(p);
      }
    }
  } catch {}
}
function log(level, ...args) {
  rotateLogs();
  const line = `[${moment().format('HH:mm:ss')}] [${level}] ${args.map(a => (typeof a === 'string' ? a : util.format(a))).join(' ')}\n`;
  try { fs.appendFileSync(`${PATHS.logs}/${moment().format('YYYY-MM-DD')}.log`, line); } catch {}
  console.log(level === 'ERROR' ? chalk.red(line) : line);
}

// === Queue helpers ===
const pushToQueue = item => { item.createdAt = Date.now(); QUEUE.push(item); writeJSON(PATHS.queue, QUEUE); log('INFO', 'Queued', item.jobId || '-', item.type); };
const popFromQueue = () => { const it = QUEUE.shift(); writeJSON(PATHS.queue, QUEUE); return it; };
const createJobId = p => `${p}-${Math.floor(Date.now()/1000)}-${Math.random().toString(36).slice(2,8)}`;

// === Adaptive delay + jitter ===
let adaptHistory = [], failStreak = 0, shouldStopAll = false;
function gaussianRandom() {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}
function computeDelay(msg = '', batch=false) {
  const base = CONFIG.MESSAGE_DELAY_MIN + Math.random() * (CONFIG.MESSAGE_DELAY_MAX - CONFIG.MESSAGE_DELAY_MIN);
  const lenFactor = Math.min(1.8, Math.max(1, msg.length / 80));
  const gauss = Math.abs(gaussianRandom()) * CONFIG.PER_MESSAGE_JITTER_MS;
  const win = adaptHistory.slice(-CONFIG.ADAPTIVE_WINDOW);
  let delay = base * lenFactor + gauss;
  if (win.length >= 5) {
    const failRatio = win.filter(x => !x.ok).length / win.length;
    if (failRatio > CONFIG.ADAPTIVE_FAIL_RATIO_THRESHOLD) delay = Math.min(CONFIG.DELAY_MAX_CAP, delay * (1 + failRatio * 3));
  }
  delay *= (0.95 + Math.random() * 0.1);
  if (batch) delay += Math.random() * CONFIG.PER_BATCH_EXTRA_JITTER_MS;
  return Math.round(delay);
}
const adjustLimit = () => {
  const win = adaptHistory.slice(-CONFIG.ADAPTIVE_WINDOW);
  if (win.length < CONFIG.ADAPTIVE_WINDOW) return;
  const r = win.filter(x => !x.ok).length / win.length;
  if (r > 0.08) USAGE.dailyLimit = Math.max(CONFIG.MIN_DAILY_LIMIT, Math.floor(USAGE.dailyLimit * 0.6));
  else if (r < 0.01 && USAGE.dailyLimit < CONFIG.INITIAL_DAILY_LIMIT) USAGE.dailyLimit = Math.min(CONFIG.INITIAL_DAILY_LIMIT, USAGE.dailyLimit + 50);
  writeJSON(PATHS.usage, USAGE);
};

// === Critical detection & smart pause ===
const isCritical = e => /(rate|spam|unauthorized|blocked|too many|quota|limit|policy)/.test((e?.message||'').toLowerCase());
const smartPause = async ms => { log('WARN', `Smart pause ${Math.round(ms/1000)}s`); shouldStopAll = true; await new Promise(r => setTimeout(r, ms)); shouldStopAll = false; };

// === WhatsApp helpers ===
async function isWhatsApp(client, jid) {
  try { const r = await client.onWhatsApp?.(jid); return r?.[0]?.exists ?? true; } catch { return true; }
}

// === Message randomization ===
const randomizeMsg = m => {
  let out = m;
  if (Math.random() < CONFIG.ADD_ZERO_WIDTH_PROB) out += CONFIG.ZERO_WIDTH;
  if (Math.random() < CONFIG.APPEND_PUNCTUATION_PROB) out += Math.random() < 0.5 ? '.' : '...';
  return out;
};

// === Presence simulation ===
function pickPresenceStyle() {
  const p = Math.random();
  const { short, long, burst, none } = CONFIG.PRESENCE_STYLE_PROBS;
  if (p < short) return 'short';
  if (p < short + long) return 'long';
  if (p < short + long + burst) return 'burst';
  return 'none';
}
async function simulatePresence(client, jid, msg) {
  try {
    if (!CONFIG.ENABLE_PRESENCE_SIM || Math.random() > CONFIG.PRESENCE_PROBABILITY) return;
    const style = pickPresenceStyle();
    let totalDur = Math.min(CONFIG.TYPING_MAX_MS, Math.max(CONFIG.TYPING_MIN_MS, Math.floor(msg.length * (10 + Math.random() * 40))));
    if (style === 'short') totalDur = Math.min(totalDur, CONFIG.TYPING_MIN_MS + 600);
    if (style === 'long') totalDur = Math.max(totalDur, CONFIG.TYPING_MAX_MS - 400);
    if (style === 'burst') totalDur = Math.max(CONFIG.TYPING_MIN_MS, Math.floor(totalDur * (0.6 + Math.random() * 1.2)));

    if (client.presenceSubscribe) try { await client.presenceSubscribe(jid); } catch {}
    const interval = CONFIG.PRESENCE_INTERVAL_MS;
    const steps = Math.max(1, Math.ceil(totalDur / interval));
    for (let i = 0; i < steps; i++) {
      if (!client.sendPresenceUpdate) break;
      const useRecording = Math.random() < 0.12;
      try { await client.sendPresenceUpdate(useRecording ? 'recording' : 'composing', jid); } catch {}
      await new Promise(r => setTimeout(r, interval + Math.floor(Math.random() * 600)));
      if (Math.random() < 0.25) { try { await client.sendPresenceUpdate('paused', jid); } catch {} await new Promise(r => setTimeout(r, 200 + Math.floor(Math.random() * 800))); }
    }
    if (client.sendPresenceUpdate) try { await client.sendPresenceUpdate('paused', jid); } catch {}
    await new Promise(r => setTimeout(r, 80 + Math.floor(Math.random() * 220)));
  } catch {}
}

// === Queue worker ===
async function queueWorker(client) {
  log('INFO', 'Worker start');
  while (true) {
    if (shouldStopAll) { await new Promise(r => setTimeout(r, 1000)); continue; }
    if (fs.existsSync(`${DATA_DIR}/stop.flag`)) { await new Promise(r => setTimeout(r, 2000)); continue; }
    if (USAGE.sentToday >= USAGE.dailyLimit) {
      const msLeft = Math.max(0, moment().endOf('day').valueOf() - Date.now());
      await smartPause(msLeft + 1000);
      continue;
    }

    let item = null;
    if (STATE?.job?.remaining?.length) item = STATE.job.remaining.shift();
    else if (QUEUE.length) { item = popFromQueue(); STATE = { job: { jobId: item.jobId || createJobId('qjob'), remaining: [], index: 0 } }; writeJSON(PATHS.state, STATE); }
    else { await new Promise(r => setTimeout(r, 1000)); continue; }

    if (!item) continue;

    try {
      if (item.type === 'text') {
        const members = item.members || [];
        for (let i = 0; i < members.length; i++) {
          if (shouldStopAll) break;
          const target = members[i];
          if (SENT[today][target]) continue;
          if (USAGE.sentToday >= USAGE.dailyLimit) break;
          const exists = await isWhatsApp(client, target).catch(() => true);
          if (!exists) continue;

          const batchFlag = (USAGE.sentToday % CONFIG.BATCH_SIZE === 0);
          const d = computeDelay(item.message, !!batchFlag);
          await new Promise(r => setTimeout(r, d));

          try {
            await simulatePresence(client, target, item.message);
            await new Promise(r => setTimeout(r, 80 + Math.floor(Math.random() * 220)));

            const msg = randomizeMsg(item.message);
            await client.sendMessage(target, { text: msg });

            USAGE.sentToday++; SENT[today][target] = true;
            writeJSON(PATHS.usage, USAGE); writeJSON(PATHS.sent, SENT);

            adaptHistory.push({ ok: true, when: Date.now() });
            failStreak = 0;

            if (USAGE.sentToday % CONFIG.BATCH_SIZE === 0) {
              await smartPause(CONFIG.LONG_COOLDOWN_MS + Math.floor(Math.random() * 2000));
            }
          } catch (err) {
            adaptHistory.push({ ok: false, when: Date.now(), err: String(err?.message || err) });
            failStreak++; log('ERROR', `Send fail ${target}:`, err?.message || err);
            if (isCritical(err)) { USAGE.dailyLimit = Math.max(CONFIG.MIN_DAILY_LIMIT, Math.floor(USAGE.dailyLimit * 0.5)); writeJSON(PATHS.usage, USAGE); await smartPause(CONFIG.SMART_PAUSE_ON_CRITICAL_MS); break; }
            if (failStreak >= CONFIG.MAX_FAIL_STREAK) { await new Promise(r => setTimeout(r, CONFIG.BACKOFF_BASE_MS * failStreak)); failStreak = 0; }
            STATE.job.remaining = members.slice(i + 1);
            writeJSON(PATHS.state, STATE);
          }

          if (adaptHistory.length >= CONFIG.ADAPTIVE_WINDOW) { adjustLimit(); adaptHistory = adaptHistory.slice(-CONFIG.ADAPTIVE_WINDOW); }
        }
      } else log('INFO', 'Unknown job type', item.type);
    } catch (e) { log('ERROR', 'Worker err', e?.message || e); }

    if (!STATE.job?.remaining?.length) { STATE = null; try { if (fs.existsSync(PATHS.state)) fs.unlinkSync(PATHS.state); } catch {} }

    await new Promise(r => setTimeout(r, 300));
  }
}

// === Exported interface ===
module.exports = function machine_v6_final(client, m) {
  if (!global.__MACHINE_V6_STARTED) {
    global.__MACHINE_V6_STARTED = true;
    queueWorker(client).catch(err => log('ERROR', 'Worker crashed', err?.message || err));
  }
  try {
    const body = (m.message?.conversation || m.message?.extendedTextMessage?.text || m.text || '').trim();
    if (!body) return;
    const prefix = /^[#/]/.test(body) ? body[0] : '#';
    const command = (body.slice(1).split(/\s+/)[0] || '').toLowerCase();
    const text = body.split(/\s+/).slice(1).join(' ');
    const from = m.chat;
    const reply = t => { try { if (typeof m.reply === 'function') return m.reply(t || ''); return client.sendMessage(from, { text: t || '' }); } catch (e) { log('ERROR', 'Reply err', e?.message || e); } };

    switch (command) {
      case 'pushkontak': {
        if (!m.isGroup) return reply('Gunakan di grup.');
        if (!text) return reply(`Contoh: ${prefix}pushkontak Halo semua`);
        client.groupMetadata(from).then(g => {
          const members = (g.participants || []).map(p => p.id).filter(x => x && x.includes('@'));
          if (!members.length) return reply('Tidak ada member valid.');
          const id = createJobId('pushk');
          pushToQueue({ type: 'text', members, message: text, jobId: id });
          reply(`✅ Job ${id} dimasukkan (${members.length} target).`);
        }).catch(e => reply('Gagal metadata: ' + (e?.message || e)));
        break;
      }
      case 'pushid': {
        if (!text.includes('|')) return reply(`Contoh: ${prefix}pushid idgroup|pesan`);
        const [idgc, ...msgParts] = text.split('|');
        const pesan = msgParts.join('|').trim();
        client.groupMetadata(idgc.trim()).then(g => {
          const members = (g.participants || []).map(p => p.id).filter(x => x && x.includes('@'));
          if (!members.length) return reply('Tidak ada member valid.');
          const id = createJobId('pushid');
          pushToQueue({ type: 'text', members, message: pesan, jobId: id });
          reply(`✅ Job ${id} dimasukkan (${members.length} target).`);
        }).catch(e => reply('Gagal ambil grup: ' + (e?.message || e)));
        break;
      }
      case 'status': reply(`Queue: ${QUEUE.length} | Sent: ${USAGE.sentToday}/${USAGE.dailyLimit} | FailStreak: ${failStreak}`); break;
      case 'cancelall': QUEUE=[]; writeJSON(PATHS.queue, QUEUE); STATE=null; try{ if(fs.existsSync(PATHS.state)) fs.unlinkSync(PATHS.state); }catch{} reply('✅ Semua job dibatalkan.'); break;
      case 'help': reply('Perintah: #pushkontak <pesan> (di grup), #pushid <idgroup>|<pesan>, #status, #cancelall'); break;
      default: break;
    }
  } catch (e) { log('ERROR', 'Cmd err', e?.message || e); }
};
