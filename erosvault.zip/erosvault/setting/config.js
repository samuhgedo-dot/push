const fs = require("fs");
const chalk = require("chalk");

// === Bot identity ===
global.owner = ["6289523191310"];
global.author = "https://github.com/samuhgedo-dot";
global.packname = "push-kontak";
global.sessionName = "WhatsApp-Session";
global.versionbot = "24.12.01";

// === Messages ===
global.mess = {
  wait: "Loading...",
  success: "Operation Sucessfull!",
  owner: "Fitur Khusus Owner Bot",
  waitdata: "Melihat Data Terkini...",
  admin: "Fitur Khusus Admin Group!",
  private: "Fitur Khusus Private Chat!",
  group: "Fitur Digunakan Hanya Untuk Group!",
  botAdmin: "Bot Harus Menjadi Admin Terlebih Dahulu!",
};

// === MACHINE.JS CONFIGURATION ===
global.machineConfig = {
  // Delay & batch
  MESSAGE_DELAY_MIN: 9000,            // minimal delay antar pesan (ms)
  MESSAGE_DELAY_MAX: 14000,           // maksimal delay antar pesan (ms)
  DELAY_MAX_CAP: 90000,               // max adaptive cap
  INITIAL_DAILY_LIMIT: 1200,
  MIN_DAILY_LIMIT: 200,
  BATCH_SIZE: 120,
  LONG_COOLDOWN_MS: 10 * 60 * 1000,
  SMART_PAUSE_ON_CRITICAL_MS: 30 * 60 * 1000,
  MAX_FAIL_STREAK: 3,
  BACKOFF_BASE_MS: 20000,
  ADAPTIVE_WINDOW: 60,
  ADAPTIVE_FAIL_RATIO_THRESHOLD: 0.05,

  // Presence / typing simulation
  ENABLE_PRESENCE_SIM: true,
  PRESENCE_PROBABILITY: 0.85,
  TYPING_MIN_MS: 800,
  TYPING_MAX_MS: 4000,
  PRESENCE_INTERVAL_MS: 1200,
  PRESENCE_STYLE_PROBS: { short: 0.25, long: 0.5, burst: 0.2, none: 0.05 },

  // Message randomization
  ADD_ZERO_WIDTH_PROB: 0.2,
  APPEND_PUNCTUATION_PROB: 0.15,
  ZERO_WIDTH: "\u200B",

  // Extra jitter
  PER_MESSAGE_JITTER_MS: 1200,
  PER_BATCH_EXTRA_JITTER_MS: 3000,

  // Logging
  LOG_MAX_BYTES: 5 * 1024 * 1024,
  LOG_RETENTION_DAYS: 7
};

// === Hot reload config.js ===
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright(`Update ${__filename}`));
  delete require.cache[file];
  require(file);
});
