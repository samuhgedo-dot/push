/*Script Created By © Neo Flare
By © Mane Official
JANGAN HAPUS CREDITS! HARGAI YANG BUAT SC?!!
HAPUS?! GUA ENC SEMUA!!? RECODE BY MANE OFFICIAL 2024-2025
*/
const fs = require('fs')
const chalk = require('chalk')

//——————————[ Config Owner ]——————————//
global.ownernumber = '' // Ganti nomer mu
global.ownername = ''

//——————————[ Config Bot ]——————————//
global.namabot = "Kurumi"
global.nomorbot = '' // Ganti no botmu
global.pair = "AMANEOFC"
global.version = '2.0.0'
global.autojoingc = false
global.anticall = false
global.autoreadsw = false
global.autoread = false

//——————————[ Config Sosmed ]——————————//
global.web = "https://saweria.co/amaneoffc"
global.linkSaluran = "https://whatsapp.com/channel/0029VbB7WPzAYlUQFsoSwS0d"
global.idSaluran = "120363400297473298@newsletter"
global.nameSaluran = "Mane Official"

//——————————[ Config Wm ]——————————//
global.packname = 'Stick By Kurumi'
global.author = 'YT Amane ofc'
global.foother = 'Made By Amane ofc'

//——————————[ Config Payment ]——————————//
//Note : Kalau gada isi aja jadi false
global.dana = "085748363750"
global.ovo = false
global.gopay = false
global.qris = "https://files.catbox.moe/lo22eo.jpg"
global.an = {
    dana: "Nezumi",
    ovo: "nama_ovo",
    gopay: "nama_gopay"
}

//——————————[ Config Media ]——————————//
global.img = "https://files.catbox.moe/5rquyi.jpg"
global.thumbxm = "https://files.catbox.moe/nzbakh.jpg"
global.thumbbc = "https://files.catbox.moe/5rquyi.jpg"
global.thumb = [ 
    "https://files.cloudkuimages.guru/images/66923e0ace81.jpg",
    "https://files.cloudkuimages.guru/images/8976c531fe4d.jpg"
]

//——————————[ Config Broadcast ]——————————//
// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 3500
global.delayPushkontak = 5000
global.namakontak = "AutoSave Kurumi"

//——————————[ Config Message ]——————————//
global.mess = {
    success: 'sᴜᴄᴄᴇssғᴜʟʏ',
    admin: '[ !! ] *sʏsᴛᴇᴍ*\nᴋʜᴜsᴜs ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ',
    botAdmin: '[ !! ] *sʏsᴛᴇᴍ*\nʙᴏᴛ ʙᴇʟᴜᴍ ᴊᴀᴅɪ ᴀᴅᴍɪɴ',
    creator: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ',
    group: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ɪɴɪ ᴋʜᴜsᴜs ɢʀᴏᴜᴘ ᴀᴊᴀ',
    private: '[ !! ] *sʏsᴛᴇᴍ*\nғᴇᴀᴛᴜʀᴇ ᴋʜᴜsᴜs ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ',
    wait: '[ !! ] *sʏsᴛᴇᴍ*\nᴡᴀɪᴛ ᴘʀᴏsᴇs ᴅᴜʟᴜ',
}



// *** message *** 
global.closeMsgInterval = 30; // 30 menit. maksimal 60 menit, minimal 1 menit
global.backMsgInterval = 2; // 2 jam. maksimal 24 jam, minimal 1 jam

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})
