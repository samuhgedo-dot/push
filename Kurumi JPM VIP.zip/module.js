module.exports = {
modul: {
	axios: require('axios'),
	baileys: require("@whiskeysockets/baileys"),
	chalk: require('chalk'),
	cheerio: require('cheerio'),
	fs: require('fs'),
	fsx: require('fs-extra'),
	keyeddb: require('@whiskeysockets/baileys'),
	moment: require('moment-timezone'),
	path: require('path'),
	FileType: require('file-type'),
	pino: require('pino'),
	process: require('process'),
	parsems: require('parse-ms'),
	os: require('os'),
	PhoneNumber: require('awesome-phonenumber'),
    util: require('util'),
    Utils: require('@whiskeysockets/baileys/lib/Utils')
}
}