/*Script Created By © Neo Flare
Recode By © Mane Official
JANGAN HAPUS CREDITS! HARGAI YANG BUAT SC?!!
HAPUS?! GUA ENC SEMUA!!? RECODE BY MANE OFFICIAL 2024-2025
*/
let handler = async (m, { mane, isAdmins, isBotAdmins, reply }) => {
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins) return reply(mess.admin);
  if (!isBotAdmins) return reply(mess.botAdmin);

  if (!m.quoted) return reply("Reply pesan yang mau dihapus, baru ketik *.delete*");

  try {
    await mane.sendMessage(m.chat, { react: { text: "👁️‍🗨️", key: m.key } });
    await mane.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.quoted.id,
        participant: m.quoted.sender
      }
    });
  } catch (err) {
    console.log(err);
    reply("❌ Gagal menghapus pesan, mungkin pesan terlalu lama atau bukan dari member.");
  }
};

handler.command = ["delete", "del"];
handler.tags = ["group"];
handler.help = ["delete"];
handler.group = true;

module.exports = handler;