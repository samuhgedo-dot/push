/*Script Created By © Neo Flare
Recode By © Mane Official
JANGAN HAPUS CREDITS! HARGAI YANG BUAT SC?!!
HAPUS?! GUA ENC SEMUA!!? RECODE BY MANE OFFICIAL 2024-2025
*/
let handler = async (m, { mane, isAdmins, isBotAdmins, reply, text }) => {
  if (!m.isGroup) return reply(mess.group);
  if (!isAdmins) return reply(mess.admin);
  if (!isBotAdmins) return reply(mess.botAdmin);

  let metadata = await mane.groupMetadata(m.chat);
  let teks = `📢 *TagAll oleh Admin*\n\n${text ? text + "\n\n" : ""}`;
  let mentionAll = metadata.participants.map(a => a.id);
  mentionAll.forEach(u => (teks += `👤 @${u.split('@')[0]}\n`));

  await mane.sendMessage(m.chat, { text: teks, mentions: mentionAll });
};

handler.command = ["tagall"];
handler.tags = ["group"];
handler.help = ["tagall"];
handler.group = true;

module.exports = handler;